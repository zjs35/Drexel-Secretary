# Url Shortener Samples

The Google URL Shortener at goo.gl is a service that takes long URLs and squeezes them into fewer characters to make a link that is easier to share, tweet, or email to friends. 

[Getting Started](https://developers.google.com/url-shortener/)

## Running the sample

`node urlshortener.js`