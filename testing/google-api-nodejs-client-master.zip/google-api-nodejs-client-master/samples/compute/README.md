# Compute Engine Metadata API Samples

The Google Compute Engine Metadata service lets you get and set key/value pairs on virtual machine instances.

[Getting Started](https://cloud.google.com/compute/docs/metadata/)

## Running the sample

`node compute.js`