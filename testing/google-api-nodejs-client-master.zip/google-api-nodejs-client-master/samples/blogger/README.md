# Blogger API Samples

The Blogger API v3 allows client applications to view and update Blogger content. Your client application can use Blogger API v3 to create new blog posts, edit or delete existing posts, and query for posts that match particular criteria.

[Getting Started](https://developers.google.com/blogger/)

## Running the sample

`node blogger.js`